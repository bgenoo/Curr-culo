function teste() {
    botao = document.querySelector("#clique")
    botao.classList.add("desativado")
    habilidades = document.querySelector("#habilidades");
    habilidades.classList.add("ativado")
}